﻿using System;

public class Node
{
    public int data;
    public Node next;

    public Node(int data)
    {
        this.data = data;
        next = null;
    }
}

public class PalindromeLinkedList
{
    public Node head;

    public PalindromeLinkedList()
    {
        head = null;
    }

    public void InsertAtEnd(int data)
    {
        Node newNode = new Node(data);
        if (head == null)
        {
            head = newNode;
        }
        else
        {
            Node temp = head;
            while (temp.next != null)
            {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public bool IsPalindrome()
    {
        if (head == null || head.next == null)
        {
            return true;
        }

        // listenin ortanca elemanini bulma
        Node slow = head;
        Node fast = head;
        while (fast.next != null && fast.next.next != null)
        {
            slow = slow.next;
            fast = fast.next.next;
        }

        // listenin 2.yarisini ters cevirme
        Node prev = null;
        Node curr = slow.next;
        Node next = null;
        while (curr != null)
        {
            next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }

        // ilk yarisi ve 2.yarisi arasinda karsilastirma
        Node firstHalf = head;
        Node secondHalf = prev;
        while (secondHalf != null)
        {
            if (firstHalf.data != secondHalf.data)
            {
                return false;
            }
            firstHalf = firstHalf.next;
            secondHalf = secondHalf.next;
        }
        return true;
    }
}

public class MainClass
{
    public static void Main()
    {
        PalindromeLinkedList list = new PalindromeLinkedList();
        Console.WriteLine("Listenin uzunlugunu giriniz.");
        int k = Convert.ToInt32(Console.ReadLine());
        
        for(int i = 0; i < k; i++)
        {
            Console.WriteLine($"Dizinin {i + 1}. elemanini giriniz. ");
            list.InsertAtEnd(Convert.ToInt32(Console.ReadLine()));
        }

        if (list.IsPalindrome())
        {
            Console.WriteLine("Liste bir palindromdur.");
        }
        else
        {
            Console.WriteLine("Liste bir palindrom degildir.");
        }
    }
}
